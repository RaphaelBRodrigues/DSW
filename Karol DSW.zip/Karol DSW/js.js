
function most1(){
document.getElementByID('de').innerHTML = "O filme, embora comece sua história com a descoberta do corpo congelado do Capitão América em 2011, grande parte de sua história se passa durante a década de 1940, durante a Segunda Guerra Mundial. É também a primeira aparição do Tesseract, a Joia do Espaço.";
}

/*
<div id="bloco2" class="bloco">
<img class="foto" src="" onmouseover="mostrar()">
<p class="nome">NOME</p>
<p id="cade" class="descriçao" onclick="most1()">Passe o Mouse aqui</p>
<p class="lançamento">DATA DE LANÇAMENTO</p>
<p class=""></p>